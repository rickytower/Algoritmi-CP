#!/usr/bin/env python3
from sys import argv, stdin, stdout, stderr

DEBUG_LEVEL = 0


def cesena(n, lista_chioschi , E):
    #print(f"called cesena({n=}, {lista_chioschi=},{E=})",file=stderr)
    return 2, [1,0], [[0,1],[0]]


if __name__ == "__main__":
    if len(argv) == 2:
        DEBUG_LEVEL = int(argv[1])

    T = int(input())
    for t in range(1, 1 + T):
        n,m,num_chioschi = map(int, input().strip().split())
        lista_chioschi = map(int, input().strip().split())
        E = []
        for _ in range(m):
            E.append(tuple(map(int, input().strip().split())))
        opt_val, opt_target_seq, opt_paths = cesena(n,lista_chioschi ,E)
        if DEBUG_LEVEL > 0:
            print(f"# {opt_val=}\n# ", file=stderr)
            print(" ".join(map(str,opt_target_seq)), file=stderr)
        print(opt_val)
        print(" ".join(map(str,opt_target_seq)))
        for p in opt_paths:
            print(" ".join(map(str,list(p))))
