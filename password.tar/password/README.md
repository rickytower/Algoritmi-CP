When a GIA authenticated student calls this service his private password gets returned.
He can use this password e.g. for decripting his own submissions to an exam sessions when the wole archive of the submissions is made publically available.

