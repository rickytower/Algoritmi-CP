This problem reveals and explains the scores you have collected on the various problems of its collection/contest.
In the case of an exam contest, it might also reveal the various marks (standard,silver,gold,platinum) already achieved up to that point.
In the case of an homework contest, it also reaveals the current value of the bonus multipliers for the various problems.
The file `points2marks.yaml` in this folder is the map that converts from total scores to bonus marks.
The file `multipliers.yaml` gives the currently planned deadlines for the time-decreasing multipliers. These deadlines might get postponed or other deadlines or even problems can be introduced, but always respecting the policy that the scores abd marks already achieved should never decrease.

